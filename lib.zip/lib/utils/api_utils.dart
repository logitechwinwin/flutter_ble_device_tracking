class ApiUtils {
  // ignore: non_constant_identifier_names
  static String BASE_URL = '';

  // Auth
  static String urlLogin = '';
  
}
