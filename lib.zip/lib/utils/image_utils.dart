
class ImageUtils {
  // png
  static const imgIcLogo = 'assets/images/png/ic_logo.jpg';
  
  // svg

  // json 
}