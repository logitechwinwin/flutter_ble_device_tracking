
class CommonService {
}
