class DeviceStatus {
  static const String connected = 'Connected';
  static const String disconnected = 'Disconnected';
}